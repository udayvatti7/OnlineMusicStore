function storeManagervalidation(){
		
	
		
		
		if(document.manager.storeid.value==0)
	    {   
	  alert("Store Id cannot be empty"); 
	  return false;
	    } 
		
		var letters = /^[A-Za-z]+$/;
		if(document.manager.firstname.value==0)
        {   
			
      alert("Firstname cannot be empty"); 
	  return false;
        } 
		if(document.manager.firstname.value.match(letters)){}
		else{
			 alert("Firstname should contain only alphabets"); 
			  return false;
		}
	
		if(document.manager.lastname.value==0)
        {   
			
      alert("Lastname cannot be empty"); 
	  return false;
        } 
		if(document.manager.lastname.value.match(letters)){}
		else{
			 alert("Lastname should contain only alphabets"); 
			  return false;
		}
		if(document.manager.address.value==0)
        {   
      alert("address cannot be empty"); 
	  return false;
        }  
		
		if(document.manager.area.value==0)
        {   
      alert("area cannot be empty"); 
	  return false;
        }  
		
		if(document.manager.street.value==0)
        {   
      alert("street cannot be empty"); 
	  return false;
        } 
		
		 var phone = /^\d{10}$/;
		  if(document.manager.phoneno.value.match(phone))   
	        {  
	        }   
	      else  
	        {   
	        alert("Phone no must be 10 digits");   
	        return false;   
	        }
		 
		  var emailid = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		  if(document.manager.email.value.match(emailid))   
	        {   
	      //alert("emailmatch");
		   
	        }   
	      else  
	        {   
	        alert("Email id must be in xxx@xxx.xxx format");   
	        return false;   
	        } 
		
		  if(document.manager.Username.value==0)
		    {   
		  alert("User name cannot be empty"); 
		  return false;
		    } 
		  
		  var PASSWORD =  /^(?=.*[0-9])(?=.*[!@$%^&*])[a-zA-Z0-9!@$%^&*]{7,15}$/;
		  //alert("suc"); 
		  if(document.manager.pwd.value.match(PASSWORD))   
	       {   
	     //alert("Pinmatch");
		   
	       }   
	     else  
	       {   
	       alert("Password must be minimum 8 digits with atleast one special character and one numeric digit(special character eg $,@)");   
	       return false;   
	       }
		  
		
	}

