function validateform()
{
	
	
var f_user=/^[A-Za-z0-9]{6,}$/;
var f_pass=/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;
var f_fname=/^[A-Za-z]{3,15}$/;
var f_mname=/^[A-Za-z]{3,15}$/;
var f_lname=/^[A-Za-z]{3,15}$/;
var f_phone=/^\d{10}/;
var f_mail=/^[A-Za-z][A-Za-z0-9\.]*[_]{0,1}[A-Za-z0-9\.]*@[A-Za-z]+\.(com)$/;

var user_type=document.updateuser.usertype;

var user=document.updateuser.username.value;

var pass=document.updateuser.password.value;

var cpass=document.updateuser.confirmpass.value;

var fname=document.updateuser.fname.value;

var mname=document.updateuser.mname.value;

var lname=document.updateuser.lname.value;

var adress=document.updateuser.adress.value;

var phone=document.updateuser.phone.value;

var mail=document.updateuser.email.value;

var city=document.updateuser.city.value;


var c=0;

if(city=="select")
{
	
document.getElementById("a11").style.visibility="visible";
c++;

}
else{
	
document.getElementById("a11").style.visibility="hidden";

}


function check() {
var d = -1;
for(var i=0; i < user_type.length; i++){
   if(user_type[i].checked) {
      d = i; 
   }
}
if (d == -1) {

document.getElementById("a1").style.visibility="visible";
c++;

}
else
{

document.getElementById("a1").style.visibility="hidden";
}
}

check();

if(!f_user.test(user))
{
	
document.getElementById("a2").style.visibility="visible";
c++;
}
else
{
	
document.getElementById("a2").style.visibility="hidden";

}

 if(!f_pass.test(pass))
{
 document.getElementById("a3").style.visibility="visible";
 c++;
 }
 else
 {
 document.getElementById("a3").style.visibility="hidden";
 }

if(pass!=cpass)
{
document.getElementById("a9").style.visibility="visible";
c++;

}
else
{
document.getElementById("a9").style.visibility="hidden";

}
if(!f_fname.test(fname))
{
document.getElementById("a4").style.visibility="visible";
c++;
}
else
{
document.getElementById("a4").style.visibility="hidden";

}
if(!f_mname.test(mname))
{
document.getElementById("a5").style.visibility="visible";
c++;
}
else
{
document.getElementById("a5").style.visibility="hidden";

}

if(!f_lname.test(lname))
{
document.getElementById("a6").style.visibility="visible";
c++;
}
else
{
document.getElementById("a6").style.visibility="hidden";
}

if(adress==null){

document.getElementById("a12").style.visibility="visible";
c++;
}
else
{
document.getElementById("a12").style.visibility="hidden";
}

if(!f_phone.test(phone))
{
document.getElementById("a7").style.visibility="visible";
c++;
}
else
{
document.getElementById("a7").style.visibility="hidden";

}


if(!f_mail.test(mail))
{
document.getElementById("a8").style.visibility="visible";
c++;
}
else
{
document.getElementById("a8").style.visibility="hidden";

}

if(c>0){
c=0;
return false;
}
else{

return true; 
}
}