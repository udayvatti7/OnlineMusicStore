   
  
	


	function storevalidation()
	{
		if(document.admin.storeId.value.match(/^[0-9]{1,}$/))
	    {   
	  
	    }  
		else{
			alert("Store Id must contain only numbers "); 
			  return false;
		}
		if(document.admin.storename.value.match(/^[a-zA-Z_]{1,}$/))
	        {   
	      
	        } 
		else{
			alert("Store name must contain only alphabets"); 
		      return false;
		}
		
				
		if(document.admin.address.value.match(/^[a-zA-Z0-9_]{1,}$/))
	        {   
	     
	        } 
		else{
			 alert("ADDRESS is invalid"); 
			  return false;
		}
		if(document.admin.are.value.match(/^[a-zA-Z0-9_]{1,}$/))
	        {   
	     
	        } 
		else{
			 alert("Area is invalid"); 
			  return false;
		}
			if(document.admin.street.value.match(/^[a-zA-Z0-9_]{1,}$/))
	        {   
	     
	        } 
			else{
				 alert("Street is invalid"); 
				  return false;
			}
			
			  
	      var pinno = /^4000[00-99]+$/;
	      
	      
	       
	      //alert("Pinmatch");
		   
	         
		  //alert("suc"); 
	      if(document.admin.pincode.value.match(/^[0-9]{1,6}$/))  
	      { 
	    	  if(document.admin.pincode.value.match(pinno))   
	        {   
	      //alert("Pinmatch");
		   
	        }   
	      else  
	        {   
	        alert("Pin no must be in 4000XX format");   
	        return false;   
	        }}
	    	  else  
	          {   
	          alert("Pin no must be 6 digits");
	    	  return false;
	          }
			
	  
	         
		
	      
		  if(document.admin.contact.value.match(/^[0-9]{1,10}$/))    
	        {   
	      //alert("Phonematch");
		     
	        }   
	      else  
	        {   
	        alert("Phone no must be 10 digits");   
	        return false;   
	        }
			
		  var emailid = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
		   //alert("suc"); 
		  
		  if(document.admin.email.value.match(emailid))   
	        {   
	      //alert("emailmatch");
		   
	        }   
	      else  
	        {   
	        alert("Email id must be in xxx@xxx.xxx format");   
	        return false;   
	        } 
			
		  
		  if(document.admin.shr.value.match(/^[0-9]{1,2}$/))
		    {   
		  	  if (document.admin.shr.value >= 0 && document.admin.shr.value <= 23) {
			  // something
		  		//alert("suc");
			}
		  	  else{
		  		alert("Please enter proper hourformat(00-23)");
				return false;
		  	  }}
		else{
			alert("Please enter proper hourformat(00-23)");
			return false;
		}

		  if(document.admin.smin.value.match(/^[0-9]{1,2}$/))
		    {   
		    	 
		  if (document.admin.smin.value >= 0 && document.admin.smin.value <= 59) {
			  // something
			  //alert("suc");
		}
		  else{
			  alert("Please enter proper minuteformat(00-59)");
			return false;
			}}
		else{
		alert("Please enter proper minuteformat(00-59)");
		return false;
		}
		
		if(document.admin.ehr.value.match(/^[0-9]{1,2}$/))
		    	    {   
		    	    	  
	if (document.admin.ehr.value >= 0 && document.admin.ehr.value <= 23) {
		  //alert("suc");
		}
	else{
		alert("Please enter proper hourformat(00-23)");
		return false;
	}}
	else{
		alert("Please enter proper hourformat(00-23)");
		return false;
	}
	if(document.admin.emin.value.match(/^[0-9]{1,2}$/))
	{   
		 if (document.admin.emin.value >= 0 && document.admin.emin.value <= 59) {
	// something
			 //alert("suc");
	}
		 else{
			 alert("Please enter proper minuteformat(00-59)");
			 return false;
		 }}
	else{
	alert("Please enter proper minuteformat(00-59)");
	return false;
	}
	if (document.admin.ehr.value== document.admin.shr.value)
	{
		if (document.admin.emin.value<= document.admin.smin.value){
			alert("Please enter proper end time (End time cannot be less than Start time)");
			return false;
		}
			
	}

			if(document.admin.capacity.value.match(/^[0-9]{1,4}$/))  
	        {   
	      //alert("capmatch");
		   
	        }   
	      else  
	        {   
	        alert("Store capacity must contain only numbers");   
	        return false;   
	        }
			
			

	}
		
		