package oms.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; //import oms.resourceManagement.Store;

import oms.resourceManagement.IndiaAdmin;
import oms.resourceManagement.User;


//chandan's import
import java.sql.SQLException;
import oms.resourceManagement.Album;
import oms.resourceManagement.ConnectionOperationsDao;
import oms.resourceManagement.FinalResult;
import oms.resourceManagement.InvalidUserNameException;
import oms.resourceManagement.MRM;
import oms.resourceManagement.MusicRegistration;
import oms.resourceManagement.UserDao;
//import oms.resourceManagement.Store;


//pooja's import


import oms.resourceManagement.CityAdmin;
import oms.resourceManagement.Store;
import oms.resourceManagement.StoreAndManagerMapping;
import oms.resourceManagement.StoreManagerRegistration;


public class OmsController extends HttpServlet {
	private static final long serialVersionUID = 1L;


      public void setAttribute(HttpServletRequest request,User user){
    	    request.setAttribute("city", user.getCity());
			request.setAttribute("usertype", user.getUserType());
			request.setAttribute("username", user.getUserName());
			request.setAttribute("pass", user.getPassword());
			request.setAttribute("fname", user.getFirstName());
			request.setAttribute("mname", user.getMiddleName());
			request.setAttribute("lname", user.getLastName());
			request.setAttribute("adress", user.getAdress());
			request.setAttribute("phone", user.getPhone());
			request.setAttribute("email", user.getEmail()); 

      }
	
      public User setUser(HttpServletRequest request,User user){
    	    user.setCity(request.getParameter("city"));
			user.setUserType(request.getParameter("usertype"));
			user.setUserName(request.getParameter("username"));
			user.setPassword(request.getParameter("password"));
			user.setFname(request.getParameter("fname"));
			user.setMiddleName(request.getParameter("mname"));
			user.setLastName(request.getParameter("lname"));
			user.setAdress(request.getParameter("adress"));
			user.setmobileNumber(request.getParameter("phone"));
			user.setEmail(request.getParameter("email"));
    	    return user;	  
      }
	public OmsController() {
		super();
		
	}
    protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	
    	//user managements code
		System.out.println("I am in get");

		if (request.getQueryString().equals("addUser")) {

			RequestDispatcher reqDisp = request
					.getRequestDispatcher("userRegistration.jsp");
			reqDisp.forward(request, response);
		}

		if (request.getQueryString().equals("viewDetails")) {
			User user = new User();
			ArrayList<User> ViewUser = user.userView();
			System.out.println("size" + ViewUser.size());
			request.setAttribute("showuser", ViewUser);
			RequestDispatcher reqDisp = request
					.getRequestDispatcher("usersList.jsp");
			reqDisp.forward(request, response);
		}

		if(request.getQueryString().equals("homepageUser")){
			 
			RequestDispatcher reqDisp=request.getRequestDispatcher("indiaAdminHomePage.jsp");
				reqDisp.forward(request, response);
		 }
		
		if(request.getQueryString().equals("logoutUser")){
			 
			RequestDispatcher reqDisp=request.getRequestDispatcher("indiaAdminLogin.jsp");
				reqDisp.forward(request, response);
		 }
		
//music management's code
		
		if("Delete".equals(request.getParameter("DeleteMusic")))
		{
			FinalResult fr=new FinalResult();
			 String AlbumId2=request.getParameter("musicName");
			 int x=Integer.parseInt(AlbumId2);
			 ArrayList <FinalResult> DeleteThealbum=fr.deleteMusic(x);
			 
			request.setAttribute("viewMusic2",DeleteThealbum);
			RequestDispatcher reqDisp=request.getRequestDispatcher("ViewMusic2.jsp");
			reqDisp.forward(request, response);
		}
		
		if("Edit".equals(request.getParameter("EditMusic")))
		{
			FinalResult fr=new FinalResult();
			String AlbumId2=request.getParameter("musicName");
			int y=Integer.parseInt(AlbumId2);
		
			 ArrayList <FinalResult> UpdateThealbum=fr.UpdateMusic(y);
			 
			
		request.setAttribute("viewMusic3",UpdateThealbum);	
		
		RequestDispatcher reqDisp=request.getRequestDispatcher("ViewMusic3.jsp");
		// System.out.println("hello.......");
			reqDisp.forward(request, response);
		}
		
 if(request.getQueryString().equals("MusicDetails")){
			 
			 FinalResult fr=new FinalResult();
				ArrayList <FinalResult> ViewThealbum=fr.viewAlbumDetails();
				request.setAttribute("viewMusiw",ViewThealbum);
			 RequestDispatcher reqDisp=request.getRequestDispatcher("OnlyMusicDetails.jsp");
				reqDisp.forward(request, response);
		 }
		
 if(request.getQueryString().equals("addMusic")){
			 
		
			 RequestDispatcher reqDisp=request.getRequestDispatcher("searchMusic.jsp");
				reqDisp.forward(request, response);
		 }

 if(request.getQueryString().equals("updateDetails")){
	 
	 FinalResult fr=new FinalResult();
		ArrayList <FinalResult> ViewThealbum=fr.viewAlbumDetails();
		request.setAttribute("viewMusic1",ViewThealbum);
	 RequestDispatcher reqDisp=request.getRequestDispatcher("ViewMusic.jsp");
		reqDisp.forward(request, response);
 }
 
 if(request.getQueryString().equals("searchMusic")){
	 
		
	 RequestDispatcher reqDisp=request.getRequestDispatcher("searchMusic.jsp");
		reqDisp.forward(request, response);
 }
 
 if(request.getQueryString().equals("home")){
	 
		
	 RequestDispatcher reqDisp=request.getRequestDispatcher("NavigationMusic.jsp");
		reqDisp.forward(request, response);
 }	
 
 if(request.getQueryString().equals("logout")){
	 
		
	 RequestDispatcher reqDisp=request.getRequestDispatcher("MRMLogin.jsp");
		reqDisp.forward(request, response);
 }	
 
 if(request.getQueryString().equals("MarketResearchManagerLogin")){
	 
		
	 RequestDispatcher reqDisp=request.getRequestDispatcher("MRMLogin.jsp");
		reqDisp.forward(request, response);
 }	
		
 if(request.getQueryString().equals("musicReg")){
	 
		
	 RequestDispatcher reqDisp=request.getRequestDispatcher("MusicUI.jsp");
		reqDisp.forward(request, response);
 }
 
 if(request.getParameter("searchmusic")!=null){
		if(request.getParameter("searchmusic").equals("searchmusic1")){

			MusicRegistration mr = new MusicRegistration();
			boolean status = false;
			String title = request.getParameter("Title1");
			
			System.out.println(""+title);
			status = mr.check(title);
			System.out.println("status:"+status);
			if (status == true) {
				RequestDispatcher reqdisp = request
						.getRequestDispatcher("oneSongDetail.jsp");
				reqdisp.forward(request, response);
			}
			else{
				RequestDispatcher reqdisp = request.getRequestDispatcher("StatusMessage1.jsp");
		reqdisp.forward(request, response);
			}

		
			
			
		}
		}
		// store management's get
 

	if(request.getQueryString().equals("addstore")){
		RequestDispatcher reqDisp=request.getRequestDispatcher("store_ui.jsp");
		reqDisp.forward(request, response);
	}

	if(request.getQueryString().equals("viewStoreDetails")){
		view(request,response);
	}
	
	if(request.getQueryString().equals("indiaAdminLogin")){
		RequestDispatcher reqDisp=request.getRequestDispatcher("indiaAdminLogin.jsp");
		reqDisp.forward(request, response);
	}
	
	if(request.getQueryString().equals("cityAdminLogin")){
		RequestDispatcher reqDisp=request.getRequestDispatcher("cityAdminLogin.jsp");
		reqDisp.forward(request, response);
	}
	
	
	}

	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		 String OnlinePrice=null;
		 String Discount=null ;

		System.out.println("I am in post");
		///user management's code

		if (request.getParameter("indiaAdminLogin") != null) {
			if (request.getParameter("indiaAdminLogin").equals("Login")) {
				IndiaAdmin indiaAdmin = new IndiaAdmin();
				boolean status = false;
				String userName = request.getParameter("indiaAdminUsernName");
				String password = request.getParameter("indiaAdminPassword");
				status = indiaAdmin.login(userName, password);
				if (status == true) {
					RequestDispatcher reqdisp = request
							.getRequestDispatcher("indiaAdminHomePage.jsp");
					reqdisp.forward(request, response);
				}
				else{
					RequestDispatcher reqDisp = request
					.getRequestDispatcher("userStatusMessage.jsp");
			reqDisp.forward(request, response);
				}

			}
		}
		

		if (request.getParameter("insertUser") != null) {
			if (request.getParameter("insertUser").equals("insert")) {
				User user = new User();
				user=setUser(request,user);
			    boolean status=user.addUser();	
			    System.out.println("Is user name in valid"+status);
				if (status==true) {
					setAttribute(request,user);
					RequestDispatcher reqdisp = request
							.getRequestDispatcher("invalidUserRegistration.jsp");
					reqdisp.forward(request, response);
					
				}
				else{
					ArrayList<User> ViewUser = user.userView();
					System.out.println("size" + ViewUser.size());
					request.setAttribute("showuser", ViewUser);
					RequestDispatcher reqDisp = request
							.getRequestDispatcher("usersList.jsp");
					reqDisp.forward(request, response);
				}
			}

		}

		if (request.getParameter("editUser") != null) {
			if (request.getParameter("editUser").equals("Edit")) {
				UserDao userDao = new UserDao();
				User user=new User();
				try {
					String id = request.getParameter("username");
					user = userDao.selectReq(id);
					setAttribute(request,user);
					RequestDispatcher reqdisp = request
							.getRequestDispatcher("userUpdate.jsp");
					reqdisp.forward(request, response);
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}

		}
		if (request.getParameter("deleteUser") != null) {
			if (request.getParameter("deleteUser").equals("Delete")) {
				boolean status = false;
				User user = new User();
				String userName = request.getParameter("username");
				status = user.deleteUser(userName);
				if (status == true) {
					ArrayList<User> ViewUser = user.userView();
					System.out.println("size" + ViewUser.size());
					request.setAttribute("showuser", ViewUser);
					RequestDispatcher reqDisp = request
							.getRequestDispatcher("usersList.jsp");
					reqDisp.forward(request, response);
				}
			}
		}
		if (request.getParameter("updateUser") != null) {
			if ("Update".equals(request.getParameter("updateUser"))) {
				User user = new User();
				setUser(request,user);
				System.out.println(request.getParameter("city"));
				boolean status=user.updateUser();
				System.out.println("Is user name in valid"+status);
				if (status==true) {
					System.out.println("i am in if");
					setAttribute(request,user);
					RequestDispatcher reqdisp = request
							.getRequestDispatcher("userUpdate.jsp");
					reqdisp.forward(request, response);
					
				}
				else{
					ArrayList<User> ViewUser = user.userView();
					System.out.println("size" + ViewUser.size());
					request.setAttribute("showuser", ViewUser);
					RequestDispatcher reqDisp = request
							.getRequestDispatcher("usersList.jsp");
					reqDisp.forward(request, response);
				}
			}
		}

		

		if (request.getParameter("userList") != null) {
			User user = new User();
			if (request.getParameter("userList").equals("usersView")) {
				ArrayList<User> ViewUser = user.userView();
				System.out.println("size" + ViewUser.size());
				request.setAttribute("showuser", ViewUser);
				RequestDispatcher reqDisp = request
						.getRequestDispatcher("usersList.jsp");
				reqDisp.forward(request, response);
			}

		}
		
		
	

	//music management's code
	
		if(request.getParameter("music")!=null){
			if(request.getParameter("music").equals("register")){
			 
		     String AlbumId= request.getParameter("AlbumId");
		     String AlbumName= request.getParameter("AlbumName");
			 String Type=request.getParameter("kind");
			 String Format=request.getParameter("format");	
			// System.out.println(""+request.getParameter("onlinepricetape"));
			 if(request.getParameter("format").equals("tape")){
				  OnlinePrice=request.getParameter("onlinepricetape");
				  Discount=request.getParameter("discounttape");	
			 }
			 else if(request.getParameter("format").equals("cd")){
				 OnlinePrice=request.getParameter("onlinepricecd");
				 Discount=request.getParameter("discountcd");	
			 }	
			 else if(request.getParameter("format").equals("dvd")){
				 OnlinePrice=request.getParameter("onlinepricedvd");
				 Discount=request.getParameter("discountdvd");	
			 }	
			 
			 String Available=request.getParameter("avail");
			 String Listings=request.getParameter("lis");
			 
			 
			
			 Album a=new Album();
			 a.setAlbumId(AlbumId);
			 a.setAlbumName(AlbumName);
			 a.setType(Type);
			 a.setFormat(Format);
			 a.setOnlinePrice(OnlinePrice);
			 a.setDiscount(Discount);
			 a.setAvailable(Available);
			 a.setListings(Listings);
			 
			 a.initialize1();
			 try {
					a.addDetails1();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			 
			 
			 String title= request.getParameter("title");
			 String AlbumId1= request.getParameter("AlbumId");
			 String Artist= request.getParameter("artiste");
			 String MusicDir= request.getParameter("md");
			 String Language= request.getParameter("lang");
			 String Genre= request.getParameter("genre");
			 MusicRegistration mr=new MusicRegistration();
			 mr.setTitle(title);
			 mr.setAlbumId(AlbumId1);
			 mr.setArtist(Artist);
			 mr.setMusicDir(MusicDir);
			 mr.setLanguage(Language);
			 mr.setGenre(Genre);
			 
			 mr.initialize();
			 try {
				mr.addDetails();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			

				FinalResult fr=new FinalResult();
			ArrayList <FinalResult> ViewThealbum=fr.viewAlbumDetails();
			
			System.out.println("size"+ViewThealbum.size());
			
			request.setAttribute("viewMusic1",ViewThealbum);
			RequestDispatcher reqDisp=request.getRequestDispatcher("ViewMusic.jsp");
			reqDisp.forward(request, response);
			}		
			
		}
			
			
			if(request.getParameter("up")!=null){
			 if(request.getParameter("up").equalsIgnoreCase("date")){
				

				
			     String AlbumId= request.getParameter("AlbumId");
			     String AlbumName= request.getParameter("AlbumName");
				 String Type=request.getParameter("kind");
				 String Format=request.getParameter("format");	
				// System.out.println(""+request.getParameter("onlinepricetape"));
				 if(request.getParameter("format").equals("tape")){
					  OnlinePrice=request.getParameter("onlinepricetape");
					  Discount=request.getParameter("discounttape");	
				 }
				 else if(request.getParameter("format").equals("cd")){
					 OnlinePrice=request.getParameter("onlinepricecd");
					 Discount=request.getParameter("discountcd");	
				 }	
				 else if(request.getParameter("format").equals("dvd")){
					 OnlinePrice=request.getParameter("onlinepricedvd");
					 Discount=request.getParameter("discountdvd");	
				 }	
				 
				 String Available=request.getParameter("avail");
				 String Listings=request.getParameter("lis");
				 
				 
				
				 Album a=new Album();
				 a.setAlbumId(AlbumId);
				 a.setAlbumName(AlbumName);
				 a.setType(Type);
				 a.setFormat(Format);
				 a.setOnlinePrice(OnlinePrice);
				 a.setDiscount(Discount);
				 a.setAvailable(Available);
				 a.setListings(Listings);
				 
				 int x=Integer.parseInt(AlbumId);
				 
				 a.initialize1();
				 try {
					a.addDetails2(x);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				 
				 
				 String title= request.getParameter("title");
				 String AlbumId1= request.getParameter("AlbumId");
				 String Artist= request.getParameter("artiste");
				 String MusicDir= request.getParameter("md");
				 String Language= request.getParameter("lang");
				 String Genre= request.getParameter("genre");
				 MusicRegistration mr=new MusicRegistration();
				 mr.setTitle(title);
				 mr.setAlbumId(AlbumId1);
				 mr.setArtist(Artist);
				 mr.setMusicDir(MusicDir);
				 mr.setLanguage(Language);
				 mr.setGenre(Genre);
				 
				 int x1=Integer.parseInt(AlbumId1);
				 
				 mr.initialize();
				 try {
					mr.addDetails2(x1);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

					FinalResult fr=new FinalResult();
				ArrayList <FinalResult> ViewThealbum=fr.viewAlbumDetails();
				
				System.out.println("size"+ViewThealbum.size());
				
				request.setAttribute("viewMusic1",ViewThealbum);
				RequestDispatcher reqDisp=request.getRequestDispatcher("ViewMusic.jsp");
				reqDisp.forward(request, response);
				
				
			}
			}
			
			
			if (request.getParameter("MRM") != null) {
				if (request.getParameter("MRM").equals("MRMLogin")) {
					MRM m = new MRM();
					boolean status = false;
					String userName = request.getParameter("MRMusername");
					String password = request.getParameter("MRMpassword");
					System.out.println(""+userName);
					status = m.login(userName, password);
					System.out.println("status:"+status);
					if (status == true) {
						RequestDispatcher reqdisp = request
								.getRequestDispatcher("NavigationMusic.jsp");
						reqdisp.forward(request, response);
					}
					else{
						RequestDispatcher reqdisp = request.getRequestDispatcher("StatusMessage.jsp");
				reqdisp.forward(request, response);
					}

				}
			}

			
//store management's post			
			
			//System.out.println("hey am here in post line" );
			if((request.getParameter("store"))!=null){
			if((request.getParameter("store")).equals("storeregistration"))
		{
				
			
			String storeid=request.getParameter("storeid");
			String firstName=request.getParameter("firstname");
			String lastName=request.getParameter("lastname");
			String address=request.getParameter("address"); 
			String area=request.getParameter("area"); 
			String street=request.getParameter("street"); 
			String mobilePhone=request.getParameter("phoneno");
			String email=request.getParameter("email"); 
			String userName=request.getParameter("Username");
			String password=request.getParameter("pwd");
			
			StoreManagerRegistration StoreManager=new StoreManagerRegistration(storeid,firstName,lastName,address,area,street, mobilePhone,email,userName, password);
			
			StoreManager.addStoreManager();	
		
			
			view(request,response);
			
		}
			}
			if(request.getParameter("add")!=null)
			{
			if(request.getParameter("add").equals("store"))
			{
				int sid=Integer.valueOf(request.getParameter("storeId"));
				String city=request.getParameter("city");
				String sname=request.getParameter("storename");
				String add=request.getParameter("address");
				String area=request.getParameter("are");
				String str=request.getParameter("street");
				Integer pc=Integer.valueOf(request.getParameter("pincode"));
				String contact=request.getParameter("contact");
				String email=request.getParameter("email");
				Integer shr=Integer.valueOf(request.getParameter("shr"));
				Integer smin=Integer.valueOf(request.getParameter("smin"));
				Integer ehr=Integer.valueOf(request.getParameter("ehr"));
				Integer emin=Integer.valueOf(request.getParameter("emin"));
				Integer capacity=Integer.valueOf(request.getParameter("capacity"));
				Store s1=new Store(sid,city,sname,add,
			            area,str,pc,contact,email,shr,smin,ehr,emin,capacity);
				s1.addStore();
				s1.addStoreAndMapping();
				view(request,response);
				
				
				}
			}
			if(request.getParameter("DeleteStore")!=null){
				if(request.getParameter("DeleteStore").equals("StoreDelete"))
				{
					int storeid=Integer.valueOf(request.getParameter("storeId"));
					System.out.println(""+storeid);
					System.out.println("am deleting ina loop");
					Store s1=new Store();
					int k=s1.deleteStore(storeid);
					view(request,response);
					
				
				
				}
			}			
			if(request.getParameter("storeupdate")!=null){
				if("UpdateStore".equals(request.getParameter("storeupdate"))){
					int storeid=Integer.valueOf(request.getParameter("storeId"));
					String city=request.getParameter("city");
					String storeName=request.getParameter("storename");
					String address=request.getParameter("address");
					String area=request.getParameter("are");
					String street=request.getParameter("street");
					Integer pincode=Integer.valueOf(request.getParameter("pincode"));
					String contact=request.getParameter("contact");
					String email=request.getParameter("email");
					Integer startHour=Integer.valueOf(request.getParameter("shr"));
					Integer startMin=Integer.valueOf(request.getParameter("smin"));
					Integer endHour=Integer.valueOf(request.getParameter("ehr"));
					Integer endMin=Integer.valueOf(request.getParameter("emin"));
					Integer capacity=Integer.valueOf(request.getParameter("capacity"));
					Store s1=new Store(storeid,city,storeName,address,
				            area,street,pincode,contact,email,startHour,startMin,endHour,endMin,capacity);
					
					
					
					
					
					s1.setStoreid(storeid);
					s1.setCity(city);
					s1.setStorename(storeName);
					s1.setAddress(address);
					s1.setArea(area);
					s1.setStreet(street);
					s1.setPincode(pincode);
					s1.setContact_details(contact);
					s1.setEmail(email);
					s1.setStart_hr(startHour);			
					s1.setStart_min(startMin);
					s1.setEnd_hr(endHour);
					s1.setEnd_min(endMin);
					s1.setCapacity(capacity);
		           
		            
		            
					int i=s1.updateStore();
					
					
					if (i==1){
						view(request,response);
						
						
					}
				}
				}
			
			
			
			if(request.getParameter("manager")!=null)
			{
					if("Edit/AddManager".equals(request.getParameter("manager")))
						{
					
						String username=request.getParameter("userName");
						String storeid=request.getParameter("storeId");
						System.out.println("hey username "+username);
						
						if(username.equals("null")){
							request.setAttribute("storeId", storeid);
							RequestDispatcher reqDisp=request.getRequestDispatcher("addManager.jsp");
							reqDisp.forward(request, response);
						}
						else{
						/*get the primary key*/
						System.out.println("hey id"+storeid);
						StoreManagerRegistration s=new StoreManagerRegistration();
						s=s.select(storeid);
						request.setAttribute("address", s.getStoreManagerAddress());
						request.setAttribute("area", s.getStoreManagerArea());
						System.out.println("area in controller" +s.getStoreManagerArea());
						request.setAttribute("street", s.getStoreManagerStreet());
						request.setAttribute("storeManager", s);
						RequestDispatcher reqDisp=request.getRequestDispatcher("EditView.jsp");
						reqDisp.forward(request, response);
						}
						}
					
			}



			if(request.getParameter("store")!=null)
			{
					if("EditStore".equals(request.getParameter("store")))
						{
					
						
						int  storeid=Integer.valueOf(request.getParameter("storeId")); /*get the primary key*/
						System.out.println("hey id"+storeid);
						Store s=new Store();
						s=s.select(storeid);
						request.setAttribute("storeDetails", s);
						RequestDispatcher reqDisp=request.getRequestDispatcher("EditStoreView.jsp");
						reqDisp.forward(request, response);
						}
			}


			if(request.getParameter("storeupdate")!=null)
			{

					if("Update".equals(request.getParameter("storeupdate"))){
						
						
						String storeid=request.getParameter("storeid");
						System.out.println(storeid);	
						System.out.println(storeid);	
						String firstName=request.getParameter("firstname");
						System.out.println("first name in controller"+firstName);
						String lastName=request.getParameter("lastname");
						String address=request.getParameter("address"); 
						String area=request.getParameter("area"); 
						String street=request.getParameter("street"); 
						String mobilePhone=request.getParameter("phoneno");
						String email=request.getParameter("email"); 
						String userName=request.getParameter("Username");
						String password=request.getParameter("pwd");
						
						StoreManagerRegistration s=new StoreManagerRegistration();
						s.setStore_Id(storeid);
						s.setFirstName(firstName);
						s.setLastName(lastName);
						s.setStoreManagerAddress(address);
						s.setStoreManagerArea(area);
						s.setStoreManagerStreet(street);
						s.setMobilePhone(mobilePhone);
						s.setStoreManagerEmail(email);
						s.setUserName(userName);
						s.setPassword(password);
			           
			            
			            
						int i=s.updateStoreManager();
						
						
						
						if (i==1){
							view(request,response);
							
						}
					}
					
	}
					
			if (request.getParameter("CityAdmin") != null) {
				if (request.getParameter("CityAdmin").equals("CityAdminLogin")) {
					CityAdmin ca = new CityAdmin();
					boolean status = false;
					String userName = request.getParameter("CityAdminusername");
					String password = request.getParameter("CityAdminpassword");
					status = ca.login(userName, password);
					System.out.println(""+status);
					if (status == true) {
						RequestDispatcher reqdisp = request
								.getRequestDispatcher("navigation.jsp");
						reqdisp.forward(request, response);
					}
					if (status == false){
						RequestDispatcher reqdisp = request
						.getRequestDispatcher("StatusMessage.jsp");
				reqdisp.forward(request, response);
					}

				}
			}
					}

			
			
			
			
			

	public void view(HttpServletRequest request,HttpServletResponse response){
		StoreManagerRegistration StoreManager=new StoreManagerRegistration();
		ArrayList<StoreAndManagerMapping> ViewTheManager=StoreManager.viewStoreManager();
		
		System.out.println("size"+ViewTheManager.size());
		request.setAttribute("view",ViewTheManager);
		RequestDispatcher reqDisp=request.getRequestDispatcher("storeManagerView.jsp");
		try {
			reqDisp.forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}		
			
			
			
	
	
}
