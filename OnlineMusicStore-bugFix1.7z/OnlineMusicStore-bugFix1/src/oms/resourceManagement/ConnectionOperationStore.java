package oms.resourceManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ConnectionOperationStore {
	ArrayList<StoreManagerRegistration> ManagerList = new ArrayList<StoreManagerRegistration>();
	ArrayList<StoreAndManagerMapping> MappingList = new ArrayList<StoreAndManagerMapping>();

	public ConnectionOperationStore() {

	}

	public static Connection generateConnection() {
		String accessDetails[] = {
				"jdbc:oracle:thin:@172.26.132.40:1521:orclilp", "a28a", "a28a" }; // change
																					// usernamepassword
		Connection temp = null;
		boolean isRollbackRequired = false;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			temp = DriverManager.getConnection(accessDetails[0],
					accessDetails[1], accessDetails[2]);
			temp.setAutoCommit(false);

		} catch (ClassNotFoundException e) {
			isRollbackRequired = true;
			e.printStackTrace();
		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
		} finally {
			if (isRollbackRequired) {
				try {
					temp.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
		return temp;
	}

	public static boolean closeConnection(Connection temp) {
		boolean isCloseConnectionSuccessful = false;
		try {
			if (temp != null) {
				temp.commit();
				temp.close();
				isCloseConnectionSuccessful = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isCloseConnectionSuccessful;
	}

	public static boolean closeResultSet(ResultSet temp) throws SQLException {
		boolean isCloseResultSetSuccessful = false;
		temp.close();
		isCloseResultSetSuccessful = true;
		return isCloseResultSetSuccessful;
	}

	public static void insert(String tableName, String[] values)
	throws SQLException {

// check conditions error code
/* function to insert value to database tables */

Connection conn = null;
boolean isRollbackRequired = false;
PreparedStatement ps = null;

try {
	conn = generateConnection();

	String query = "INSERT INTO " + tableName + " VALUES(";

	for (int i = 0; i < values.length - 1; i++) {
		query = query + "?,";
	}
	query = query + "?)";

	System.out.println(query);

	ps = conn.prepareStatement(query);

	for (int i = 0; i < values.length; i++) {
		ps.setString(i + 1, values[i]);
	}

	int a = ps.executeUpdate();
	System.out.println("Update Status : " + a);
	conn.commit();
} catch (SQLException e) {
	isRollbackRequired = true;
	e.printStackTrace();
	throw e;
} catch (NullPointerException e) {
	isRollbackRequired = true;
	e.printStackTrace();
} finally {
	try {
		if (isRollbackRequired)
			conn.rollback();

		ps.close();
		closeConnection(conn);
	} catch (SQLException e) {
		e.printStackTrace();
	}

}

}

	public static void  updateMappingAdding(String[] values){
		Connection conn = null;
		boolean isRollbackRequired = false;
		PreparedStatement ps = null;
		try {
			conn = generateConnection();
			String sql2 = "update storeandmanagermapping set username='"+values[8]+"'"+
			"where store_id='"+ values[0]+"'";
			ps = conn.prepareStatement(sql2);
			int executing = ps.executeUpdate();

		System.out.println("Update Status : " +executing);
		conn.commit();
	} catch (SQLException e) {
		isRollbackRequired = true;
		e.printStackTrace();
		
	} finally {
		try {
			if (isRollbackRequired)
				conn.rollback();

			ps.close();
			closeConnection(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}




	public ArrayList<StoreAndManagerMapping> StoreManagerView()
			throws SQLException {

		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement Pstmt = null;
		boolean isRollbackRequired = false;


		try {
			conn = generateConnection();
			/* write the qwery */
			System.out.println("sql");
			String sql = "SELECT s.store_id,s.city,s.storecapacity,SM.username FROM STORE2 s LEFT OUTER JOIN STOREMANAGERLIST sm ON s.STORE_ID=sm.store_id";
			System.out.println(sql);

			Pstmt = conn.prepareStatement(sql);
			rs = Pstmt.executeQuery();
			System.out.println("entering rs");
			while (rs.next()) {
				System.out.println("in result set");
				/*
				 * StoreManagerRegistration Sm=new StoreManagerRegistration();
				 * Store st=new Store();
				 */
				int storeid = Integer.parseInt(rs.getString(1));
				int Store_id1 = (storeid);
				String City1 = (rs.getString(2));
				int capacity = Integer.parseInt(rs.getString(3));
				int Capacity1 = (capacity);
				/*
				 * c.setFirstName(rs.getString(2));
				 * c.setLastName(rs.getString(3));
				 * c.setStoreManagerAddress(rs.getString(4));
				 * c.setStoreManagerArea(rs.getString(5));
				 * c.setStoreManagerStreet(rs.getString(6));
				 * c.setMobilePhone(rs.getString(7));
				 * c.setStoreManagerEmail(rs.getString(8));
				 */
				String UserName1 = (rs.getString(4));
				// c.setPassword(rs.getString(10));
				StoreAndManagerMapping SMP = new StoreAndManagerMapping(
						Store_id1, City1, Capacity1, UserName1);

				MappingList.add(SMP);
				System.out.println("size  of mappimg " + MappingList.size());
				conn.commit();
			}
			return MappingList;

		} catch (SQLException e) {
			System.out.println("excpetion");
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();

				rs.close();
				Pstmt.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

	}

	public int StoreManagerUpdate(String tableName, String s[])
			throws SQLException {
		Connection conn = null;
		// ResultSet rs = null;
		PreparedStatement Pstmt = null;
		boolean isRollbackRequired = false;
		// PreparedStatement ps = null;
		System.out.println(s[0]);

		int store_id = Integer.parseInt(s[0]);

		try {
			conn = generateConnection();
			String sql = " UPDATE " + tableName + " " + " SET FirstName='"
					+ s[1] + "'," + "LastName='" + s[2] + "',Address='" + s[3]
					+ "'," + "Area='" + s[4] + "',Street='" + s[5] + "',"
					+ "MobileNO='" + s[6] + "',Email='" + s[7] + "',"
					+ "username='" + s[8] + "'," + "Password='" + s[9]
					+ ",' where store_id=" + store_id + "";

			System.out.println(sql);

			Pstmt = conn.prepareStatement(sql);
			Pstmt.executeUpdate();
			conn.commit();

		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();

				// rs.close();
				Pstmt.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		return 1;
	}

	public StoreManagerRegistration selectStoreManager(int storeid) {

		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;
		StoreManagerRegistration s = new StoreManagerRegistration();

		try {
			conn = generateConnection();
			String sql = "SELECT * FROM STOREMANAGERLIST where Store_Id='"
					+ storeid + "'";
			System.out.println(sql);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				
				s.setStore_Id(Integer.toString(storeid));
				s.setFirstName(rs.getString(2));
				s.setLastName(rs.getString(3));
				s.setStoreManagerAddress(rs.getString(4));
				s.setStoreManagerArea(rs.getString(5));
				s.setStoreManagerStreet(rs.getString(6));
				s.setMobilePhone(rs.getString(7));
				s.setStoreManagerEmail(rs.getString(8));
				s.setUserName(rs.getString(9));
				s.setPassword(rs.getString(10));


			}

				

		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();

		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				pstmt.close();
				rs.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		System.out.println("in connection class" + s.getStore_Id());
		return s;
	}

	public boolean userLogin(String userName, String password) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;
		boolean status = false;
		try {
			conn = generateConnection();
			String sql = "select username,password from users where usertype='City Administrater'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);

			while (rs.next()) {
				String username = rs.getString("username");
				String passw = rs.getString("password");
				if (userName.equals(username) && password.equals(passw)) {
					status = true;
					System.out.println("sdf");
					break;
				}
				System.out.println("" + status);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				pstmt.close();
				rs.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return status;

	}

}
