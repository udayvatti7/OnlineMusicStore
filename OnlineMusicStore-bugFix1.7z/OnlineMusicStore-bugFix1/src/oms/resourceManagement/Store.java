package oms.resourceManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Store {
	private int storeid;
	private String storename;
	private String city;
	private String address;
	private String area;
	private String street;
	private int pincode;
	private String contact_details;
	private String email;
	private int start_hr;private int start_min;
	private int end_hr;private int end_min;
	private int capacity;
	
	
	public Store(){
		
	}
	
	
	public Store(int storeid, String city,String storename,  String address,
			String area, String street, int pincode, String contactDetails,
			String email, int startHr,int startMin,int endHr,int endMin,
			int capacity) {
		super();
		this.storeid=storeid;
		this.city = city;
		this.storename = storename;
		this.address = address;
		this.area = area;
		this.street = street;
		this.pincode = pincode;
		this.contact_details = contactDetails;
		this.email = email;
		start_hr = startHr;
		start_min = startMin;
		end_hr = endHr;
		end_min = endMin;
		this.capacity = capacity;
	}
	public int getStoreid() {
		return storeid;
	}
	public void setStoreid(int storeid) {
		this.storeid = storeid;
	}
	public String getStorename() {
		return storename;
	}
	public void setStorename(String storename) {
		this.storename = storename;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getContact_details() {
		return contact_details;
	}
	public void setContact_details(String contactDetails) {
		contact_details = contactDetails;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getStart_hr() {
		return start_hr;
	}
	public void setStart_hr(int startHr) {
		start_hr = startHr;
	}
	public int getStart_min() {
		return start_min;
	}
	public void setStart_min(int startMin) {
		start_min = startMin;
	}
	public int getEnd_hr() {
		return end_hr;
	}
	public void setEnd_hr(int endHr) {
		end_hr = endHr;
	}
	public int getEnd_min() {
		return end_min;
	}
	public void setEnd_min(int endMin) {
		end_min = endMin;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	
	
	PreparedStatement pst=null;
	PreparedStatement pst1=null;
	
	public int addStore() {
		Connection conn=DbConnect.create();
		int insertCount = 0;
		String sql = "Insert into STORE2 values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		//String sql2="Insert into storeandmanagermapping values (?)";
		System.out.println(""+sql);
		//System.out.println(""+sql2);
		try {
	
			pst = conn.prepareStatement(sql);
			//pst1 = conn.prepareStatement(sql2);
			pst.setInt(1,storeid );
			pst.setString(2,city );
			pst.setString(3,storename);
			pst.setString(4,address);
			pst.setString(5,area);
			pst.setString(6,street);
			pst.setInt(7,pincode);
			pst.setString(8,contact_details);	        
			pst.setString(9,email);
			pst.setInt(10,start_hr);
			pst.setInt(11,start_min);
			pst.setInt(12,end_hr);
			pst.setInt(13,end_min);
			pst.setInt(14,capacity);
			System.out.println(""+sql);
			
			//pst1.setInt(1, storeid);
			
			insertCount=pst.executeUpdate();
			//int insertCount1=pst1.executeUpdate();
			System.out.println("insert count :- " + insertCount);

		} catch (SQLException ep) {
			// TODO Auto-generated catch block
			
				return 0;
			
		} 

		finally {

			if (conn != null) {
				try {

					pst.close();
					DbConnect.close(conn);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
						
					}
				}
	
}
		return 1;
	}	

	
	public int addStoreAndMapping() {
		Connection conn=DbConnect.create();
		int insertCount = 0;
		String sql2="Insert into STOREANDMANAGERMAPPING values(?,?)";
		System.out.println(""+sql2);
		try {
			pst1 = conn.prepareStatement(sql2);
			pst1.setInt(1, storeid);
			pst1.setString(2, "null");
			System.out.println(""+storeid);
			insertCount=pst1.executeUpdate();
			System.out.println("insert count :- " + insertCount);

		} catch (SQLException ep) {
			// TODO Auto-generated catch block
			
				return 0;
			
		} 

		finally {

			if (conn != null) {
				try {

					pst.close();
					DbConnect.close(conn);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
						
					}
				}
	
}
		return 1;
	}	

			
			
			
			
			
			
	public int updateStore() {
		Connection conn=DbConnect.create();
		int insertCount = 0;
		String sql = "UPDATE STORE2 SET CITY=?,STORENAME=?,STORECAPACITY=?,ADDRESS=?,AREA=?,STREET=?,PINCODE=?,CONTACT_DETAILS=?,EMAIL=?,STORETIMESTARTHR=?,STORETIMESTARTMIN=?,STORETIMEENDHR=?,STORETIMEENDMIN=? WHERE STORE_ID=?";
		try {
	
			pst = conn.prepareStatement(sql);
			pst.setInt(14,storeid );
			pst.setString(1,city );
			pst.setString(2,storename);
			pst.setString(4,address);
			pst.setString(5,area);
			pst.setString(6,street);
			pst.setInt(7,pincode);
			pst.setString(8,contact_details);	        
			pst.setString(9,email);
			pst.setInt(10,start_hr);
			pst.setInt(11,start_min);
			pst.setInt(12,end_hr);
			pst.setInt(13,end_min);
			pst.setInt(3,capacity);
						   			
			
			insertCount=pst.executeUpdate();
			System.out.println("insert count :- " + insertCount);

		} catch (SQLException ep) {
			// TODO Auto-generated catch block
			
				return 0;
			
		} 

		finally {

			if (conn != null) {
				try {

					pst.close();
					DbConnect.close(conn);

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					
						
					}
				}
	
}
		return 1;
	}
	
	
	
	public int deleteStore(int storeid) {
		Connection conn=DbConnect.create();
		// TODO Auto-generated method stub
		int insertCount = 0;
		String sql ="DELETE FROM STORE2 WHERE STORE_ID=?";
		System.out.println(sql);
			try {
			
			pst = conn.prepareStatement(sql);
			pst.setInt(1,storeid );
			insertCount=pst.executeUpdate();
			System.out.println("insert count :- " + insertCount);
	}catch (SQLException ep) {
		// TODO Auto-generated catch block
		
		return 0;
	
} 

finally {

	if (conn != null) {
		try {

			pst.close();
			DbConnect.close(conn);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
				
			}
		}

}
return 1;
}	

	

public ArrayList<StoreAndManagerMapping> viewStoreManager(){
	DbConnect.create();
	ArrayList<StoreAndManagerMapping> a=null;
	try {
		ConnectionOperationStore C=new ConnectionOperationStore();
	a=C.StoreManagerView();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return a;
}
public Store select(int storeid )
{
	DbConnect.create();
	//ConnectionOperationStore con=new ConnectionOperationStore();
	Store s=null;

      s=selectStoreManager(storeid);
      
      return s;

}

public Store selectStoreManager(int storeid)
{
	
	Connection conn = null;
	ResultSet rs = null;
	PreparedStatement pstmt = null;
	boolean isRollbackRequired = false;
	Store store1=new Store();
	

	try {
		 conn=DbConnect.create();
		String sql = "SELECT * FROM STORE2 where Store_Id='"+storeid+"'";
		System.out.println(sql);
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		
		while (rs.next()) {
			store1.setStoreid(Integer.valueOf(rs.getString(1)));
			store1.setCity(rs.getString(2));
			store1.setStorename(rs.getString(3));
			store1.setAddress(rs.getString(4));
			store1.setArea(rs.getString(5));
			store1.setStreet(rs.getString(6));
			store1.setPincode(Integer.valueOf(rs.getString(7)));
			store1.setContact_details(rs.getString(8));
			store1.setEmail(rs.getString(9));
			store1.setStart_hr(Integer.valueOf(rs.getString(10)));
			store1.setStart_min(Integer.valueOf(rs.getString(11)));
			store1.setEnd_hr(Integer.valueOf(rs.getString(12)));
			store1.setEnd_min(Integer.valueOf(rs.getString(13)));
			store1.setCapacity(Integer.valueOf(rs.getString(14)));

			
			
			
		}
		

	} 
	catch (SQLException e) {
		isRollbackRequired = true;
		e.printStackTrace();
		
	} 
	finally {
		try {
			if (isRollbackRequired)
				conn.rollback();
			pstmt.close();
			rs.close();
			DbConnect.close(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		
}
	//System.out.println("in connection class"+ store1.getArea());
	return store1 ;	
}
}


	

