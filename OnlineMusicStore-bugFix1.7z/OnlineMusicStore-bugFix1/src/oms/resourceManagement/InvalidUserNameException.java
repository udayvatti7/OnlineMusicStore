package oms.resourceManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@SuppressWarnings("serial")
public class InvalidUserNameException extends Exception {

	private boolean status = false;

	public boolean isUserNameInvalid(String userName) {

		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;

		try {
			conn = UserDao.generateConnection();
			String sql = "SELECT USERNAME FROM USERS where username='"
					      + userName + "'";
			System.out.println(sql);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String username = rs.getString("username");
				if (userName.equals(username)) {
					status = true;
					break;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				pstmt.close();
				UserDao.closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return status;
	}

}
