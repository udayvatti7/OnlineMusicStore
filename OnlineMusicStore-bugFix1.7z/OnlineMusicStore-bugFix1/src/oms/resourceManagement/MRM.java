package oms.resourceManagement;

public class MRM {

	private String userName;
	private String password;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean login(String userName,String password){
		boolean status=false;
		ConnectionOperationsDao conn= new ConnectionOperationsDao();

		status=conn.userLogin(userName, password);
     	System.out.println(status);
		return status;
	}
}
