package oms.resourceManagement;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class User {
	private String city, userType, userName, password, firstName, middleName,
			lastName, adress, email, mobileNumber;
	private ArrayList<User> userList = new ArrayList<User>();

	public ArrayList<User> getUserList() {
		return userList;
	}

	public void setUserList(ArrayList<User> userList) {
		this.userList = userList;
	}

	String a[] = new String[10];

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFname(String fname) {
		this.firstName = fname;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getPhone() {
		return mobileNumber;
	}

	public void setmobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public ArrayList<User> userView() {
		ArrayList<User> a = null;
		try {
			UserDao d = new UserDao();
			a = d.userView();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return a;
	}

	public void assignData() {

		a[0] = getCity();
		a[1] = getUserType();
		a[2] = getUserName();
		a[3] = getPassword();
		a[4] = getFirstName();
		a[5] = getMiddleName();
		a[6] = getLastName();
		a[7] = getAdress();
		a[8] = getPhone();
		a[9] = getEmail();

	}

	public boolean addUser() {
		boolean status = false;
		try {
			InvalidUserNameException exception = new InvalidUserNameException();
			assignData();
			status = exception.isUserNameInvalid(a[2]);
			if (status == true) {
				throw new InvalidUserNameException();
			} else {
				UserDao.insert("users", a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InvalidUserNameException e) {
			System.out.println("User Name " + a[2] + " already Exists");
			JOptionPane.showMessageDialog(null, "User Name " + a[2]
					+ " already Exists");
			e.printStackTrace();
		}
		return status;

	}

	public boolean updateUser() {
		boolean status = false;
		try {
			
			InvalidUserNameException exception = new InvalidUserNameException();
			String a[] = new String[11];
			assignData();
			status = exception.isUserNameInvalid(a[2]);
			if (status == true) {
				throw new InvalidUserNameException();
			} else {
				UserDao C = new UserDao();
                C.userUpdate("USERS", a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (InvalidUserNameException e) {
			System.out.println("User Name " + a[2] + " already Exists");
			JOptionPane.showMessageDialog(null, "User Name " + a[2]
					+ " already Exists");
			e.printStackTrace();
		}
		return status;
	}

	public boolean deleteUser(String userName) {

		UserDao d = new UserDao();
		boolean status = false;
		try {
			status = d.deleteUser(userName);
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;
	}

}
