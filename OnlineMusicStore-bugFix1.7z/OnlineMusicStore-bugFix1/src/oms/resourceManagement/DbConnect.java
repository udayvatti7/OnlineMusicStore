package oms.resourceManagement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnect {
	public static Connection create() {
		Connection con = null;
		
		try {
			System.out.println(" going to get connection");
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@172.26.132.40:1521:orclilp";
			String user = "a28a";
			String password = "a28a";
			System.out.println(" connection obtained status " + con);
			con = DriverManager.getConnection(url, user, password);
			con.setAutoCommit(false);
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		} 
			

		
		return con;
	}

	public static void close(Connection con) {
		try {
			System.out.println(" going to close connection");
			if (con != null) {
				con.commit();
				con.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
