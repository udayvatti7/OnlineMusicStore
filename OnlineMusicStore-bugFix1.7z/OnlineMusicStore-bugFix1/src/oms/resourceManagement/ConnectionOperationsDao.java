package oms.resourceManagement;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class ConnectionOperationsDao 
{


	public ConnectionOperationsDao(){}
 
	 ArrayList<FinalResult>  Result1=new ArrayList<FinalResult>();
	
	  
	public static Connection generateConnection()
	{
		String accessDetails[] = {"jdbc:oracle:thin:@172.26.132.40:1521:orclilp",
				"a28a","a28a"};  
		Connection temp = null;
		boolean isRollbackRequired = false;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			temp = DriverManager.getConnection(accessDetails[0],accessDetails[1],accessDetails[2]);
			temp.setAutoCommit(false);
			
		}
		catch (ClassNotFoundException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		} 
		catch (SQLException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally
		{
			if(isRollbackRequired)
			{
				try
				{
					temp.rollback();
				} 
				catch (SQLException e1) 
				{
					e1.printStackTrace();
				}
			}
		}
		return temp;
	}
	
	public static boolean closeConnection(Connection temp)
	{
		boolean isCloseConnectionSuccessful = false;
		try 
		{
			if(temp!=null)
			{
				temp.commit();
				temp.close();
				isCloseConnectionSuccessful = true;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return isCloseConnectionSuccessful;
	}
	
	public static boolean closeResultSet(ResultSet temp) throws SQLException
	{
		boolean isCloseResultSetSuccessful = false;
		temp.close();
		isCloseResultSetSuccessful = true;
		return isCloseResultSetSuccessful;
	}
	
	
	public static void insert(String tableName,String[] values)throws SQLException 
	{	

		//check conditions error code
		
		Connection conn = null;
		boolean isRollbackRequired = false;
		PreparedStatement ps = null;
		
		try 
		{
			conn = generateConnection();
			
			String query = "INSERT INTO "+tableName+" VALUES(";
			
			for(int i=0;i<values.length-1;i++)
			{
				query = query + "?,";
			}
			query = query + "?)";
			
			System.out.println(query);
			
			ps = conn.prepareStatement(query);
			
			for(int i=0;i<values.length;i++)
			{
				ps.setString(i+1,values[i]);
			}
			
			int a = ps.executeUpdate();
			 conn.commit();
			System.out.println("Update Status : "+a);
		} 
		catch (SQLException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				if(isRollbackRequired){
					conn.rollback();
				}
				else{
					conn.commit();
				}
				ps.close();
				closeConnection(conn);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	
	}
	
	public static void insert1(String[] values)throws SQLException 
	{	

		//check conditions error code
		
		Connection conn = null;
		boolean isRollbackRequired = false;
		PreparedStatement ps = null;
		
		try 
		{
			conn = generateConnection();
			
         String query = "INSERT INTO ALBUMLIST(AlbumId,AlbumName,Type1,Format," +
         		"OnlinePrice,Discount,Availability,Listings) " +
         		"values(?,?,?,?,?,?,?,?)";
	
         String AlbumId1 = null,AlbumName1 = null,Type1 = null,Format1 = null,
         OnlinePrice1 = null,Discount1 = null,Available1 = null,Listings1 = null;
         
         for(int i=0;i<values.length;i++){
         AlbumId1=values[0];
         AlbumName1=values[1];
         Type1=values[2];
         Format1=values[3];
         OnlinePrice1=values[4];
         Discount1=values[5];
         Available1=values[6];
         Listings1=values[7];

         }
         ps = conn.prepareStatement(query);
	
			ps = conn.prepareStatement(query);
			ps.setString(1,AlbumId1);
			ps.setString(2,AlbumName1);
			ps.setString(3,Type1);
			ps.setString(4,Format1);
			ps.setString(5,OnlinePrice1);
			ps.setString(6, Discount1);
			ps.setString(7,Available1);
			ps.setString(8, Listings1);
			
			
			int a = ps.executeUpdate();
			 conn.commit();
			System.out.println("Update Status : "+a);
		} 
		catch (SQLException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				if(isRollbackRequired){
					conn.rollback();
				}
				else{
					conn.commit();
				}
				ps.close();
				closeConnection(conn);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	
	}
	
	public  ArrayList<FinalResult> viewMusic()throws SQLException 
	{ 
	
	Connection conn = null;
	ResultSet rs = null;
	PreparedStatement Pstmt = null;
				boolean isRollbackRequired = false;
			
				
	try 
	{
	conn = generateConnection();
		String sql = "SELECT a.AlbumId,a.AlbumName,m.Title,m.Artiste," +
				"m.MusicDirector,m.Language ,m.Genre ,a.Type1,a.Format ," +
				"a.OnlinePrice ,a.Discount, a.Availability,a.Listings  " +
				" from ALBUMLIST a,MUSICLIST m" +
				" where a.AlbumId=m.AlbumId"  ;
		System.out.println(sql);
		
		Pstmt = conn.prepareStatement(sql);
		 rs= Pstmt.executeQuery();
		 conn.commit();
		 while(rs.next())
	{
			


	 String AlbumId2=rs.getString(1);
	 String AlbumName2=rs.getString(2);
	 String Title2=rs.getString(3);
	 String Artiste2=rs.getString(4);
	 String MusicDirector2=rs.getString(5);
	 String Language2=rs.getString(6);
	 String Genre2=rs.getString(7);
	 String Type2=rs.getString(8);
	 String Format2=rs.getString(9);
	 String OnlinePrice2=rs.getString(10);
	 String Discount2=rs.getString(11);
	 String Availability2=rs.getString(12);
	 String Listings2=rs.getString(13);
	
	 FinalResult fr=new FinalResult(AlbumId2,AlbumName2,Title2,Artiste2,
			 MusicDirector2,Language2,Genre2,Type2,Format2,OnlinePrice2,
			 Discount2,Availability2,Listings2);
	 

	 Result1.add(fr);
	
	
	
	

	}


	}catch (SQLException e) 
	{
		isRollbackRequired = true;
		e.printStackTrace();
		throw e;
	}
	catch (NullPointerException e) 
	{
		isRollbackRequired = true;
		e.printStackTrace();
	}
	finally
	{
		try 
		{
			if(isRollbackRequired){
				conn.rollback();
			}
			else{
				conn.commit();
			}

			Pstmt.close();
			rs.close();
			closeConnection(conn);
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}

	}

	return Result1;
}
	
	public  ArrayList<FinalResult> deleteMusic(int AlbumId)throws SQLException {
		
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement Pstmt = null;
					boolean isRollbackRequired = false;
				
					
		try 
		{
		conn = generateConnection();
			String sql1 = "DELETE FROM ALBUMLIST a where a.AlbumId="+AlbumId+"" ;
					

			System.out.println(sql1);
			
			Pstmt = conn.prepareStatement(sql1);
			 Pstmt.executeUpdate();
			 
			 String sql2="SELECT a.AlbumId,a.AlbumName,m.Title,m.Artiste," +
			 		"m.MusicDirector,m.Language ,m.Genre ,a.Type1,a.Format ," +
			 		"a.OnlinePrice ,a.Discount, a.Availability,a.Listings  " +
				" from ALBUMLIST a,MUSICLIST m" +
				" where a.AlbumId=m.AlbumId"  ;
			 System.out.println(sql2);
				
				Pstmt = conn.prepareStatement(sql2);
				 rs= Pstmt.executeQuery();
			
				 conn.commit();
			 while(rs.next())
		{
				
				 String AlbumId2=rs.getString(1);
				 String AlbumName2=rs.getString(2);
				 String Title2=rs.getString(3);
				 String Artiste2=rs.getString(4);
				 String MusicDirector2=rs.getString(5);
				 String Language2=rs.getString(6);
				 String Genre2=rs.getString(7);
				 String Type2=rs.getString(8);
				 String Format2=rs.getString(9);
				 String OnlinePrice2=rs.getString(10);
				 String Discount2=rs.getString(11);
				 String Availability2=rs.getString(12);
				 String Listings2=rs.getString(13);

		
				 FinalResult fr=new FinalResult(AlbumId2,AlbumName2,Title2,Artiste2,
						 MusicDirector2,Language2,Genre2,Type2,Format2,OnlinePrice2,
						 Discount2,Availability2,Listings2);
				 

				 Result1.add(fr);
				
		}
			
			 
		

		}catch (SQLException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				if(isRollbackRequired){
					conn.rollback();
				}
				else{
					conn.commit();
				}

				Pstmt.close();
		
				rs.close();
				closeConnection(conn);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}

		}

		return Result1;
		
	}
	
	
	public  ArrayList<FinalResult> updateMusic(int AlbumId)throws SQLException{
		
		Connection conn = null;
		ResultSet rs1 = null;
	
		PreparedStatement Pstmt = null;
	
					boolean isRollbackRequired = false;
				
					
					
		try 
		{
		conn = generateConnection();
		
		 
			String sql1 = "SELECT * FROM ALBUMLIST a,MUSICLIST m " +
					"WHERE a.ALBUMID="+AlbumId+" AND a.ALBUMID =m.ALBUMID ";
			

			System.out.println(sql1);
			
			Pstmt = conn.prepareStatement(sql1);
			 
				 rs1= Pstmt.executeQuery();
				 
				
					conn.commit();
			 while(rs1.next())
		{
				
				String AlbumId2=rs1.getString(1);
				String AlbumName2=rs1.getString(2);
				String Type2=rs1.getString(5);
				String Format2=rs1.getString(6);
				String OnlinePrice2=rs1.getString(7);
				String Discount2=rs1.getString(8);
				String Availability2=rs1.getString(9);
				String Listings2=rs1.getString(10);
				String Title2=rs1.getString(12);
				
				String Artiste2=rs1.getString(14);
				String MusicDirector2=rs1.getString(15);
				String Language2=rs1.getString(16);
				String Genre2=rs1.getString(17);

		

				 FinalResult fr=new FinalResult(AlbumId2,AlbumName2,Title2,
						 Artiste2, MusicDirector2,Language2,Genre2,Type2,
						 Format2,OnlinePrice2,Discount2,Availability2,Listings2);
				 

				 Result1.add(fr);
		}
			
			
			
			
			 
		

		}
		
		catch (SQLException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		
		finally
		{
			try 
			{
				if(isRollbackRequired){
					conn.rollback();
				}
				else{
					conn.commit();
				}

				Pstmt.close();
			
		
				rs1.close();
			
				closeConnection(conn);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}

		}


		return Result1;
	}

	public static void updateInsert1(String[] values,int x) throws SQLException {
		
		

		//check conditions error code
		
		Connection conn = null;
		boolean isRollbackRequired = false;
		PreparedStatement pstmt = null;
		PreparedStatement ps = null;
		
		try 
		{
			conn = generateConnection();
			
			String sql1 = "DELETE FROM ALBUMLIST a where a.AlbumId="+x+"" ;
			

			System.out.println(sql1);
			
			pstmt = conn.prepareStatement(sql1);
			 pstmt.executeUpdate();
			
         String query = "INSERT INTO ALBUMLIST(AlbumId,AlbumName,Type1," +
         		"Format,OnlinePrice,Discount,Availability,Listings)" +
         		" values(?,?,?,?,?,?,?,?)";
	
         String AlbumId1 = null,AlbumName1 = null,Type1 = null,
         Format1 = null,OnlinePrice1 = null,Discount1 = null,
         Available1 = null,Listings1 = null;
         for(int i=0;i<values.length;i++){
         AlbumId1=values[0];
         AlbumName1=values[1];
         Type1=values[2];
         Format1=values[3];
         OnlinePrice1=values[4];
         Discount1=values[5];
         Available1=values[6];
         Listings1=values[7];

         }
         ps = conn.prepareStatement(query);
	
			ps = conn.prepareStatement(query);
			ps.setString(1,AlbumId1);
			ps.setString(2,AlbumName1);
			ps.setString(3,Type1);
			ps.setString(4,Format1);
			ps.setString(5,OnlinePrice1);
			ps.setString(6, Discount1);
			ps.setString(7,Available1);
			ps.setString(8, Listings1);
			
			
			int a = ps.executeUpdate();
			 conn.commit();
			System.out.println("Update Status : "+a);
		} 
		catch (SQLException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				if(isRollbackRequired){
					conn.rollback();
				}
				else{
					conn.commit();
				}
				ps.close();
				closeConnection(conn);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	
	
		
	}
	
	public static void updateInsert(String tableName,String[] values,int x1)throws SQLException {
		
		

		//check conditions error code
		
		Connection conn = null;
		boolean isRollbackRequired = false;
		PreparedStatement ps = null;
		PreparedStatement pstmt = null;
		
		try 
		{
			conn = generateConnection();
			
           String sql1 = "DELETE FROM "+tableName+"  " +
              "where AlbumId="+x1+"" ;
			

			System.out.println(sql1);
			
			 pstmt = conn.prepareStatement(sql1);
			 pstmt.executeUpdate();
			
			String query = "INSERT INTO "+tableName+" VALUES(";
			
			for(int i=0;i<values.length-1;i++)
			{
				query = query + "?,";
			}
			query = query + "?)";
			
			System.out.println(query);
			
			ps = conn.prepareStatement(query);
			
			for(int i=0;i<values.length;i++)
			{
				ps.setString(i+1,values[i]);
			}
			
			int a = ps.executeUpdate();
			 conn.commit();
			System.out.println("Update Status : "+a);
		} 
		catch (SQLException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				if(isRollbackRequired){
					conn.rollback();
				}
				else{
					conn.commit();
				}
				ps.close();
				closeConnection(conn);
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	
	
	}
	
	public boolean userLogin(String userName,String password){
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;	
		boolean status=false;	
		try {
			conn = generateConnection();
			String sql = "select username,password from USERS " +
					"WHERE USERTYPE ='Market Research Manager'";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);

			while (rs.next()) {
				String username = rs.getString("username");
				String passw = rs.getString("password");			
				if (userName.equals(username) && password.equals(passw)) {
				  status=true;
	              break;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				pstmt.close();
				rs.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		   return status;

	}

	public boolean checkSong(String title2) {
		
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;	
		boolean status=false;	
		try {
			conn = generateConnection();
			String sql = "select TITLE from MUSICLIST " ;
					
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);

			while (rs.next()) {
				String title = rs.getString(1);
						System.out.println("current title"+title+title2);
				if (title2.equalsIgnoreCase(title)) {
					System.out.println("i am in if");
				  status=true;
	              break;
				}
			}
		} 
		 catch (SQLException e) {
			e.printStackTrace();
		}
		catch (NullPointerException e) 
		{
			isRollbackRequired = true;
			e.printStackTrace();
		}
		finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				pstmt.close();
				rs.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		   return status;

	}

}
