package oms.resourceManagement;


import java.sql.SQLException;

import java.util.ArrayList;




public class StoreManagerRegistration {
private String  store_Id;
private String firstName;
private String lastName;
private String storeManagerAddress;
private String storeManagerArea;
private String storeManagerStreet;
private String storeManagerMobilePhone;
private String storeManagerEmail;
private String userName;
private String password;




	public StoreManagerRegistration(String storeid,String firstName, String lastName,
									String address,String area,
									String street,String mobilePhone,
									String email, String userName,
									String password) {
		        this.store_Id=storeid;
		        this.firstName = firstName;
				this.lastName = lastName;
				this.storeManagerAddress = address;
				this.storeManagerArea = area;
				this.storeManagerStreet = street;
				this.storeManagerMobilePhone = mobilePhone;
				this.storeManagerEmail = email;
				this.userName = userName;
				this.password = password;
		
	}
	public StoreManagerRegistration(){
		
	}
	

	public String getStore_Id() {
		return store_Id;
	}

	public void setStore_Id(String storeId) {
		this.store_Id = storeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStoreManagerAddress() {
		return storeManagerAddress;
	}

	public void setStoreManagerAddress(String address) {
		this.storeManagerAddress = address;
	}

	public String getStoreManagerArea() {
		return storeManagerArea;
	}

	public void setStoreManagerArea(String area) {
		this.storeManagerArea = area;
	}

	public String getStoreManagerStreet() {
		return storeManagerStreet;
	}

	public void setStoreManagerStreet(String street) {
		this.storeManagerStreet = street;
	}

	public String getMobilePhone() {
		return storeManagerMobilePhone;
	}

	public void setMobilePhone(String mobilePhone) {
		this.storeManagerMobilePhone = mobilePhone;
	}

	public String getStoreManagerEmail() {
		return storeManagerEmail;
	}

	public void setStoreManagerEmail(String email) {
		this.storeManagerEmail = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void addStoreManager(){

		String a[]=new String[10];
		a[0]=getStore_Id();
		a[1]=getFirstName();
		System.out.println("name"+a[1]);
		a[2]=getLastName();
		a[3]=getStoreManagerAddress();
		a[4]=getStoreManagerArea();
		a[5]=getStoreManagerStreet();
		a[6]=getMobilePhone();
		a[7]=getStoreManagerEmail();
		a[8]=getUserName();
		a[9]=getPassword();
		
		try {
			ConnectionOperationStore.insert("STOREMANAGERLIST", a);
			ConnectionOperationStore.updateMappingAdding(a);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public ArrayList<StoreAndManagerMapping> viewStoreManager(){
		ArrayList<StoreAndManagerMapping> a=null;
		try {
			ConnectionOperationStore C=new ConnectionOperationStore();
		a=C.StoreManagerView();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
	
	
	public StoreManagerRegistration select(String storeid )
	{

		ConnectionOperationStore con=new ConnectionOperationStore();
		StoreManagerRegistration s=null;
		int storeid1=Integer.parseInt(storeid);
	      s=con.selectStoreManager(storeid1);
	      System.out.println("in model"+s.getStore_Id());
	      return s;

	}
	
	
	public int  updateStoreManager(){
		
		
			String a[]=new String[10];
			a[0]=getStore_Id();
			
			System.out.println("model"+a[0]);
			a[1]=getFirstName();
			System.out.println("name"+a[1]);
			a[2]=getLastName();
			a[3]=getStoreManagerAddress();
			a[4]=getStoreManagerArea();
			a[5]=getStoreManagerStreet();
			a[6]=getMobilePhone();
			a[7]=getStoreManagerEmail();
			a[8]=getUserName();
			a[9]=getPassword();
			try {
				ConnectionOperationStore C=new ConnectionOperationStore();
		C.StoreManagerUpdate("STOREMANAGERLIST",a);
	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 1;
	}
	
	}

