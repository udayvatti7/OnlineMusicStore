package oms.resourceManagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDao {
	ArrayList<User> userList = new ArrayList<User>();

	public static Connection generateConnection() {

		String accessDetails[] = {
				"jdbc:oracle:thin:@172.26.132.40:1521:orclilp", "a28a", "a28a" };
		Connection temp = null;
		boolean isRollbackRequired = false;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");

			temp = DriverManager.getConnection(accessDetails[0],
					accessDetails[1], accessDetails[2]);
			temp.setAutoCommit(false);

		} catch (ClassNotFoundException e) {
			isRollbackRequired = true;
			e.printStackTrace();
		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			if (isRollbackRequired) {
				try {
					temp.rollback();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
		return temp;
	}

	public static boolean closeConnection(Connection temp) {
		boolean isCloseConnectionSuccessful = false;
		try {
			if (temp != null) {
				temp.commit();
				temp.close();
				isCloseConnectionSuccessful = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return isCloseConnectionSuccessful;
	}

	public static boolean closeResultSet(ResultSet temp) throws SQLException {
		boolean isCloseResultSetSuccessful = false;
		temp.close();
		isCloseResultSetSuccessful = true;
		return isCloseResultSetSuccessful;
	}

	public ArrayList<User> userView() throws SQLException {

		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;

		try {
			conn = generateConnection();
			String sql = "SELECT * FROM USERS";
			System.out.println(sql);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			conn.commit();
			while (rs.next()) {
				User c = new User();
				c.setCity(rs.getString(1));
				c.setUserType(rs.getString(2));
				c.setUserName(rs.getString(3));
				c.setPassword(rs.getString(4));
				c.setFname(rs.getString(5));
				c.setMiddleName(rs.getString(6));
				c.setLastName(rs.getString(7));
				c.setAdress(rs.getString(8));
				c.setmobileNumber(rs.getString(9));
				c.setEmail(rs.getString(10));
				userList.add(c);

			}

		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();

				closeResultSet(rs);
				pstmt.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return userList;
	}

	public User selectReq(String id) throws SQLException {

		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;
		User c = new User();

		try {
			conn = generateConnection();
			String sql = "SELECT * FROM USERS where username='" + id + "'";
			System.out.println(sql);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {

				c.setCity(rs.getString(1));
				c.setUserType(rs.getString(2));
				c.setUserName(rs.getString(3));
				c.setPassword(rs.getString(4));
				c.setFname(rs.getString(5));
				c.setMiddleName(rs.getString(6));
				c.setLastName(rs.getString(7));
				c.setAdress(rs.getString(8));
				c.setmobileNumber(rs.getString(9));
				c.setEmail(rs.getString(10));

			}

		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				pstmt.close();
				closeResultSet(rs);
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return c;

	}

	public static void insert(String tableName, String[] values)
			throws SQLException {

		// check conditions error code

		Connection conn = null;
		boolean isRollbackRequired = false;
		PreparedStatement ps = null;

		try {
			conn = generateConnection();

			String query = "INSERT INTO " + tableName + " VALUES(";

			for (int i = 0; i < values.length - 1; i++) {
				query = query + "?,";
			}
			query = query + "?)";

			System.out.println(query);

			ps = conn.prepareStatement(query);

			for (int i = 0; i < values.length; i++) {
				ps.setString(i + 1, values[i]);
			}

			int a = ps.executeUpdate();
			System.out.println("Update Status : " + a);
			conn.commit();
		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();

				ps.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

	public int userUpdate(String tableName, String[] s) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		boolean isRollbackRequired = false;

		try {
			conn = generateConnection();
			System.out.println(s[1] + s[2] + s[3] + s[4] + s[5] + s[6] + s[7]
					+ s[8] + s[9] + s[10]);
			String sql = " UPDATE " + tableName + " " + " SET city='" + s[0]
					+ "'," + "usertype='" + s[1] + "',username='" + s[2] + "',"
					+ "password='" + s[3] + "',firstname='" + s[4] + "',"
					+ "middlename='" + s[5] + "',lastname='" + s[6]
					+ "',adress='" + s[7] + "',mobilephone='" + s[8]
					+ "',email='" + s[9] + "' where username='" + s[2] + "'";
			System.out.println(sql);
			ps = conn.prepareStatement(sql);
			ps.executeUpdate();
			conn.commit();
		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				ps.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		return 1;
	}

	public boolean deleteUser(String userName) throws SQLException {

		Connection conn = null;

		PreparedStatement Pstmt = null;
		boolean isRollbackRequired = false;

		try {
			conn = generateConnection();
			String sql = "DELETE FROM USERS a where a.username='" + userName
					+ "'";
			System.out.println(sql);
			Pstmt = conn.prepareStatement(sql);
			Pstmt.executeUpdate();
			conn.commit();

		} catch (SQLException e) {
			isRollbackRequired = true;
			e.printStackTrace();
			throw e;
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired) {
					conn.rollback();
				} else {
					conn.commit();
				}

				Pstmt.close();
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return true;
	}

	public boolean userLogin(String userName, String password) {
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		boolean isRollbackRequired = false;
		boolean status = false;
		try {
			conn = generateConnection();
			String sql = "select username,password from INDIAADMIN";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery(sql);

			while (rs.next()) {
				String username = rs.getString("username");
				String passw = rs.getString("password");
				if (userName.equals(username) && password.equals(passw)) {
					status = true;
					break;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		} finally {
			try {
				if (isRollbackRequired)
					conn.rollback();
				pstmt.close();
				closeResultSet(rs);
				closeConnection(conn);
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
		return status;

	}

}
