package oms.resourceManagement;

import java.sql.SQLException;






public class Album {
	
	private String albumId;
	private String albumName;
	private String Type;
	private String Format;
	private String onlinePrice;
	private String Discount;
	private String Available;
	private String Listings;
	
	String []details=new String[8];
	
	public  Album(){}

	
	
	public String getAlbumId() {
		return albumId;
	}






	public void setAlbumId(String albumId) {
		this.albumId = albumId;
	}






	public String getAlbumName() {
		return albumName;
	}






	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}






	public String getType() {
		return Type;
	}






	public void setType(String type) {
		Type = type;
	}






	public String getFormat() {
		return Format;
	}






	public void setFormat(String format) {
		Format = format;
	}






	public String getOnlinePrice() {
		return onlinePrice;
	}






	public void setOnlinePrice(String onlinePrice) {
		this.onlinePrice = onlinePrice;
	}






	public String getDiscount() {
		return Discount;
	}






	public void setDiscount(String discount) {
		Discount = discount;
	}






	public String getAvailable() {
		return Available;
	}






	public void setAvailable(String available) {
		Available = available;
	}






	public String getListings() {
		return Listings;
	}






	public void setListings(String listings) {
		Listings = listings;
	}



	
	
	
	
	public void initialize1() {
	
		this.details[0] = getAlbumId();
		this.details[1] = getAlbumName();
		this.details[2] = getType();
		this.details[3] = getFormat();
		this.details[4] = getOnlinePrice();
		this.details[5] = getDiscount();
		this.details[6] = getAvailable();
		this.details[7] = getListings();
	
	
	}






public  void addDetails1() throws SQLException{
	

	ConnectionOperationsDao.insert1(details) ;
		
	
}



public void addDetails2(int x) throws SQLException {

	ConnectionOperationsDao.updateInsert1(details,x) ;
	
}



}
