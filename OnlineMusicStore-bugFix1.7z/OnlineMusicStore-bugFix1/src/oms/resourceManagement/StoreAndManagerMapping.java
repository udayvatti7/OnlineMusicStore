package oms.resourceManagement;

public class StoreAndManagerMapping {
	

	private int capacity1;
	
	private int store_id1;
	private String city1;
	
	private String userName1;
	

	public StoreAndManagerMapping( int storeId1, String city1,int capacity1,
			String userName1) {
		super();
		this.capacity1 = capacity1;
		this.store_id1 = storeId1;
		this.city1 = city1;
		this.userName1 = userName1;
	}
	
	
	

	public int getCapacity1() {
		return capacity1;
	}

	public void setCapacity1(int capacity1) {
		this.capacity1 = capacity1;
	}

	public int getStore_id1() {
		return store_id1;
	}

	public void setStore_id1(int storeId1) {
		this.store_id1 = storeId1;
	}

	public String getCity1() {
		return city1;
	}

	public void setCity1(String city1) {
		this.city1 = city1;
	}

	public String getUserName1() {
		return userName1;
	}

	public void setUserName(String userName1) {
		this.userName1 = userName1;
	}

}
