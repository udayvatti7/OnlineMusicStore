package oms.resourceManagement;

import java.sql.SQLException;






public class MusicRegistration {

	private String Title;
	private String AlbumId;
	private String Artist;
	private String musicDir;
	private String Language;
	private String Genre;
	
	String []details=new String[6];
	
	public MusicRegistration(){}
	

	
	public String getTitle() {
		return Title;
	}






	public void setTitle(String title) {
		Title = title;
	}






	public String getAlbumId() {
		return AlbumId;
	}






	public void setAlbumId(String albumId) {
		AlbumId = albumId;
	}






	public String getArtist() {
		return Artist;
	}






	public void setArtist(String artist) {
		Artist = artist;
	}






	public String getMusicDir() {
		return musicDir;
	}






	public void setMusicDir(String musicDir) {
		this.musicDir = musicDir;
	}






	public String getLanguage() {
		return Language;
	}






	public void setLanguage(String language) {
		Language = language;
	}






	public String getGenre() {
		return Genre;
	}






	public void setGenre(String genre) {
		Genre = genre;
	}







	
	
	
	public void initialize() {
	
		this.details[0] = getTitle();
		this.details[1]= getAlbumId();
		this.details[2]= getArtist();
		this.details[3]= getMusicDir();
		this.details[4] = getLanguage();
		this.details[5] = getGenre();
	}






public  void addDetails() throws SQLException{
	

	ConnectionOperationsDao.insert("MUSICLIST ",details) ;
		
	
}



public void addDetails2(int x1) throws SQLException {
	
	ConnectionOperationsDao.updateInsert("MUSICLIST ",details,x1) ;
	
}



public boolean check(String title2) {
	
	
		boolean status=false;
		ConnectionOperationsDao conn= new ConnectionOperationsDao();

		status=conn.checkSong(title2);
     	System.out.println(status);
		return status;
	
}




}
