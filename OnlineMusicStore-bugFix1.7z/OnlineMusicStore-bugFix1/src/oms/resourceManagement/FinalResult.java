package oms.resourceManagement;

import java.sql.SQLException;
import java.util.ArrayList;

public class FinalResult {
	
	private String albumId2;
	private String albumName2;
	private String title2;
	private String artiste2;
	private String musicDirector2;
	private String language2;
	private String genre2;
	private String type2;
	private String format2;
	private String onlinePrice2;
	private String discount2;
	private String availability2;
	private String Listings2;
	
	
	public FinalResult(){}
	
	public FinalResult(String albumId2, String albumName2, String title2,
			String artiste2, String musicDirector2, String language2,
			String genre2, String type2, String format2, String onlinePrice2,
			String discount2, String availability2,String Listings2) {
		 
		this.albumId2=albumId2;
		this.albumName2=albumName2;
		this.title2=title2;
		this.artiste2=artiste2;
		this.musicDirector2=musicDirector2;
		this.language2=language2;
		this.genre2=genre2;
		this.type2=type2;
		this.format2=format2;
		this.onlinePrice2=onlinePrice2;
		this.discount2=discount2;
		this.availability2=availability2;
		this.Listings2=Listings2;
	}

	
	
	public String getAlbumId2() {
		return albumId2;
	}



	public void setAlbumId2(String albumId2) {
		this.albumId2 = albumId2;
	}



	public String getAlbumName2() {
		return albumName2;
	}



	public void setAlbumName2(String albumName2) {
		this.albumName2 = albumName2;
	}



	public String getTitle2() {
		return title2;
	}



	public void setTitle2(String title2) {
		this.title2 = title2;
	}



	public String getArtiste2() {
		return artiste2;
	}



	public void setArtiste2(String artiste2) {
		this.artiste2 = artiste2;
	}



	public String getMusicDirector2() {
		return musicDirector2;
	}



	public void setMusicDirector2(String musicDirector2) {
		this.musicDirector2 = musicDirector2;
	}



	public String getLanguage2() {
		return language2;
	}



	public void setLanguage2(String language2) {
		this.language2 = language2;
	}



	public String getGenre2() {
		return genre2;
	}



	public void setGenre2(String genre2) {
		this.genre2 = genre2;
	}



	public String getType2() {
		return type2;
	}



	public void setType2(String type2) {
		this.type2 = type2;
	}



	public String getFormat2() {
		return format2;
	}



	public void setFormat2(String format2) {
		this.format2 = format2;
	}



	public String getOnlinePrice2() {
		return onlinePrice2;
	}



	public void setOnlinePrice2(String onlinePrice2) {
		this.onlinePrice2 = onlinePrice2;
	}



	public String getDiscount2() {
		return discount2;
	}



	public void setDiscount2(String discount2) {
		this.discount2 = discount2;
	}



	public String getAvailability2() {
		return availability2;
	}



	public void setAvailability2(String availability2) {
		this.availability2 = availability2;
	}

	public String getListings2() {
		return Listings2;
	}



	public void setListings2(String Listings2) {
		this.Listings2 = Listings2;
	}


	public  ArrayList<FinalResult> viewAlbumDetails(){
		ArrayList<FinalResult> a=null;
		try {
			ConnectionOperationsDao conn=new ConnectionOperationsDao();
		a=conn.viewMusic();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
	
	public  ArrayList<FinalResult> deleteMusic(int AlbumId2){
		ArrayList<FinalResult> a=null;
		try {
			ConnectionOperationsDao conn=new ConnectionOperationsDao();
		a=conn.deleteMusic(AlbumId2);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
	
	public  ArrayList<FinalResult> UpdateMusic(int AlbumId2){
		ArrayList<FinalResult> a=null;
		try {
			ConnectionOperationsDao conn=new ConnectionOperationsDao();
		a=conn.updateMusic(AlbumId2);
		
		 System.out.println("hello......."+a);
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}

}
